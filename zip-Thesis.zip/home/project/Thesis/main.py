def main():
	#main
	
def setup():
	#declare all variables
	
	
if __name__ == "__main__":
	main()
	
