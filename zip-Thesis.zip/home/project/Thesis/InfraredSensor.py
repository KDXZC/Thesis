from gpiozero import DigitalInputDevice
import time

class InfraredSensor:
    def __init__(self, pin):
        self.sensor = DigitalInputDevice(pin)
        
    def get_reading(self):
        return self.sensor.is_active
        
    def wait_for_motion(self):
        self.sensor.wait_for_active()
