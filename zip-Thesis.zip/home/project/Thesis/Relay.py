import RPi.GPIO as GPIO

class RelayController:
    def __init__(self, pin):
        self.pin = pin
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.pin, GPIO.OUT)

    def turn_on_relay(self):
        GPIO.output(self.pin, GPIO.HIGH)
        print("Relay turned on")

    def turn_off_relay(self):
        GPIO.output(self.pin, GPIO.LOW)
        print("Relay turned off")
