import paho.mqtt.client as mqtt

class MQTTSubscriber:
    def __init__(self, server, port, topic, message_callback):
        self.server = server
        self.port = port
        self.topic = topic
        self.message_callback = message_callback

    def connect(self):
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.connect(self.server, self.port)
        self.client.loop_forever()

    def on_connect(self, client, userdata, flags, rc):
        print("Connected with result code " + str(rc))
        self.client.subscribe(self.topic)

    def on_message(self, client, userdata, msg):
        payload = msg.payload.decode('utf-8')
        self.message_callback(payload)

    def cleanup(self):
        self.client.disconnect()

##The connect method sets up the MQTT client and starts
##the loop to receive messages. The on_connect method is
##called when the client successfully connects to the MQTT broker
##and subscribes to the specified topic.

##The connect method sets up the MQTT client and starts the loop to receive messages.
##The on_connect method is called when the client successfully connects to the MQTT broker
##and subscribes to the specified topic. The on_message method is called when a new
##message is received on the subscribed topic. It decodes the payload of the message and
##passes it to the specified message callback function.

##Finally, the cleanup method is used to disconnect the MQTT client when the program is finished.
